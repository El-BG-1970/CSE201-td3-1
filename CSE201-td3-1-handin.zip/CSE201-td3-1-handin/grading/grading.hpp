#ifndef TEST_HPP
#define TEST_HPP

#include <iostream>

namespace tdgrading {
int grading(std::ostream &out, const int test_case);
}

#endif // TEST_HPP
